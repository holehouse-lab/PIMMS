pip install -e . --upgrade --force-reinstall
